sinatra-bootstrap-clean
=======================

Cleaned version of https://github.com/bootstrap-ruby/sinatra-bootstrap
